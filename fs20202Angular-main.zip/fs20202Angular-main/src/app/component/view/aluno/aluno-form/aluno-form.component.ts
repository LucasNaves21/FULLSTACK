import { AlunoService } from './../../../../service/aluno.service';
import { Aluno } from './../../../../model/aluno.model';
import { Pessoa } from './../../../../model/pessoa.model';
import { Curso } from './../../../../model/curso.model';
import { PessoaService } from './../../../../service/pessoa.service';
import { CursoService } from './../../../../service/curso.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-aluno-form',
  templateUrl: './aluno-form.component.html',
  styleUrls: ['./aluno-form.component.css']
})

export class AlunoFormComponent implements OnInit {

  titulo : string = "Cadastrar novo Aluno";
  dtInicio: string;
  ativo: boolean;

  aluno: Aluno = {
  pessoa: null,
  curso: null,
  dtInicio: null,
  ativo: null,
}

pessoas: Pessoa[] = [];
cursos: Curso[] = [];

constructor(
  private service: AlunoService,
  private router: Router,
  private pessoaService: PessoaService,
  private cursoService: CursoService
) { }

ngOnInit(): void {
  this.pessoaService.findAll().subscribe(pessoas =>{
    this.pessoas = pessoas;

  this.cursoService.findAll().subscribe(cursos => {
    this.cursos = cursos;
  })
  });
}

  salvar(): void {
    
    this.aluno.dtInicio = new Date(this.dtInicio) ;
    this.service.create(this.aluno).subscribe(() =>{
    this.service.showMessage("Aluno cadastrado com sucesso.")
    this.router.navigate(['/aluno/list']);
    
    });
  }
}
