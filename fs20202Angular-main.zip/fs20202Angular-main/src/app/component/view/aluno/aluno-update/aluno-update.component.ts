import { FormatDatePipe } from './../../../../util/pipe/format-date.pipe';
import { AlunoService } from './../../../../service/aluno.service';
import { PessoaService } from './../../../../service/pessoa.service';
import { Pessoa } from './../../../../model/pessoa.model';
import { Curso } from './../../../../model/curso.model';
import { CursoService } from './../../../../service/curso.service';
import { Aluno } from './../../../../model/aluno.model';
import { Component, OnInit, PipeTransform } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-aluno-update',
  templateUrl: './../aluno-form/aluno-form.component.html',
  styleUrls: ['./../aluno-form/aluno-form.component.css']
})
export class AlunoUpdateComponent implements OnInit {

  titulo : string = "Alterar dados do Aluno";
  dtInicio: string;
  ativo: boolean;

  aluno: Aluno = {
  pessoa: null,
  curso: null,
  dtInicio: null,
  ativo: null,

  }

  pessoas: Pessoa[] = [];
  cursos: Curso[] = [];

  constructor(
    private route: ActivatedRoute,
    private service: AlunoService,
    private pessoaService: PessoaService,
    private cursoService: CursoService,
    private router: Router,
  ) { }

  ngOnInit(): void {
    let id = this.route.snapshot.paramMap.get('id')
    this.service.findById(id).subscribe(aluno => {
      this.aluno = aluno;
      console.log(this.aluno);
      this.dtInicio = aluno.dtInicio.toString().substr(0, 10);
      console.log(this.dtInicio);

      this.pessoaService.findAll().subscribe(pessoas =>{
        this.pessoas = pessoas;
      });

      this.cursoService.findAll().subscribe(cursos =>{
        this.cursos = cursos;
      });
    });

    
  }
  salvar(): void {
      this.aluno.dtInicio = new Date(this.dtInicio) ;
      this.service.update(this.aluno).subscribe(() =>{
        this.service.showMessage("Aluno alterado com sucesso!");
        this.router.navigate(['/aluno/list']);
      })
  }

}