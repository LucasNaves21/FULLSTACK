import { MatriculaService } from './../../../../service/matricula.service';
import { Matricula } from './../../../../model/matricula.model';
import { Aluno } from './../../../../model/aluno.model';
import { Oferta } from './../../../../model/oferta.model';
import { AlunoService } from './../../../../service/aluno.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OfertaService } from 'src/app/service/oferta.service';

@Component({
  selector: 'app-matricula-form',
  templateUrl: './matricula-form.component.html',
  styleUrls: ['./matricula-form.component.css']
})
export class MatriculaFormComponent implements OnInit {

  titulo : string = "Cadastrar Matricula";
  matricula: Matricula = {
    aluno: null,
    oferta: null,
  }

  alunos: Aluno[] = [];
  ofertas: Oferta[] = []; 

  constructor(
    private service: MatriculaService,
    private alunoService: AlunoService,
    private ofertaService: OfertaService, 
    private router: Router
  ) { }

  ngOnInit(): void {
    this.alunoService.findAll().subscribe(alunos =>{
        this.alunos = alunos;
    });
        this.ofertaService.findAll().subscribe(ofertas =>{
            this.ofertas = ofertas;
        });
  }

  salvar(): void {
    this.service.create(this.matricula).subscribe(() =>{
      this.service.showMessage("Matricula cadastrado com sucesso.")
      this.router.navigate(['/matricula/list']);
    })
  }

}
