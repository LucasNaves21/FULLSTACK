export interface Disciplina {
    idDisciplina?: number;
    nmDisciplina: string;
    cargaHoraria: number;
}