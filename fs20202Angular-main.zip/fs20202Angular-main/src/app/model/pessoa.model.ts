export interface Pessoa {
    idPessoa?: number;
    nmPessoa: string;
    cpf: number;
    dtNascimento: Date; 
}