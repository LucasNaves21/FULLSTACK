export interface Curso {
    idCurso?: number;
    nmCurso: string;
}