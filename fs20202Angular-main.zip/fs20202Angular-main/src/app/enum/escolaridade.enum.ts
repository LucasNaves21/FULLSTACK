export enum Escolaridade {
    MEDIO = "Médio",
	GRADUACAO = "Graduação",
	ESPECIALIZACAO = "Especialização",
	MESTRADO = "Mestrado",
	DOUTORADO = "Doutorado"
} 