package br.ufg.inf.aula4.ctrl.exception;

public class DisciplinaExection extends Exception {

	private static final long serialVersionUID = 1L;

	public DisciplinaExection(String msg) {
		super(msg);
	}
}
