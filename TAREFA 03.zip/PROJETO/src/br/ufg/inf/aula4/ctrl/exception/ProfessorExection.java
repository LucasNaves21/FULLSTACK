package br.ufg.inf.aula4.ctrl.exception;

public class ProfessorExection extends Exception {

	private static final long serialVersionUID = 1L;

	public ProfessorExection(String msg) {
		super(msg);
	}
}
