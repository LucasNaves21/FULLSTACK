package br.ufg.inf.aula4.ctrl.negocio;

import java.util.List;

import br.ufg.inf.aula4.ctrl.exception.CursoExection;
import br.ufg.inf.aula4.model.dao.CursoDAO;
import br.ufg.inf.aula4.model.entities.Curso;

public class CursoNegocio {


		CursoDAO dao = new CursoDAO();
	
		public Curso inserir(Curso curso) throws CursoExection {
			this.validarCurso(curso);
			dao.inserir(curso);
			return curso;
		}
		
		// READ
		public List<Curso> buscaTodos() throws CursoExection{
			return dao.buscaTodos();	
		}
		
		public Curso buscaPorId(Integer id) throws CursoExection {
			
			return dao.buscaPorId(id);
		}
		
		
		// UPDATE
		
		public Curso alterar(Curso curso) throws CursoExection {		
			this.validarCurso(curso);
			return dao.alterar(curso);
		}
		
		// DELETE
		
		public void excluir(Integer id) throws CursoExection {
			dao.excluir(id);
		}
		
		
		private void validarCurso(Curso curso) throws CursoExection {
		
			if (curso.getNmCurso() == null || curso.getNmCurso().length() == 0) {
				throw new CursoExection("Nome do Curso � obrigat�rio.");
			}
		}
}
