package br.ufg.inf.aula4.ctrl.exception;

public class AlunoExection extends Exception {

	private static final long serialVersionUID = 1L;

	public AlunoExection(String msg) {
		super(msg);
	}
}
