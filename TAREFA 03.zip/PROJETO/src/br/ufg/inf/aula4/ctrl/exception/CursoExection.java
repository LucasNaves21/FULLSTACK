package br.ufg.inf.aula4.ctrl.exception;

public class CursoExection extends Exception {

	private static final long serialVersionUID = 1L;

	public CursoExection(String msg) {
		super(msg);
	}
}
