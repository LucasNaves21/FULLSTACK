package br.ufg.inf.aula4.ctrl.exception;

public class OfertaExection extends Exception {

	private static final long serialVersionUID = 1L;

	public OfertaExection(String msg) {
		super(msg);
	}
}
