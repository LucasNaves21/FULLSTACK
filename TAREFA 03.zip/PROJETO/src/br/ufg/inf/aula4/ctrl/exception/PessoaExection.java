package br.ufg.inf.aula4.ctrl.exception;

public class PessoaExection extends Exception {

	private static final long serialVersionUID = 1L;

	public PessoaExection(String msg) {
		super(msg);
	}
}
